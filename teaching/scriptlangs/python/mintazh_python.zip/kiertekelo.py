import unittest
import feladat


def diff(kapott, elvart):
    return f"\n\tKapott:\t{kapott}\n\tElvart:\t{elvart}"


pontszam = 0


class TestFeladat(unittest.TestCase):
    def setUp(self):
        self.telo1 = feladat.Telefon("MEDIMADIPHONE")
        self.telo2 = feladat.Telefon("EPOLFON", 3480)
        self.feladat_pont = 0
        self.apps1 = {"facebook": 135, "messenger": 369, "discord": 139}
        self.apps2 = {"facebook": 169, "messenger": 188, "discord": 138}
        self.apps3 = {"facebook": 169, "messenger": 188, "discord": 138, "instagram": 211}

    def test_init(self):
        global pontszam
        msg = "A konstruktor nem allitotta be jol"
        sorozatszam = "MEDIMADIPHONE"
        maxtarhely = 4000
        print("Konstruktor tesztelese:")
        print("-" * 30)
        try:
            self.assertEqual(self.telo1.sorozatszam, sorozatszam,
                             msg=f"{msg} a sorozatszam adattag erteket.{diff(self.telo1.sorozatszam, sorozatszam)}")
            self.feladat_pont += 2
        except Exception as e:
            print(e)

        try:
            self.assertEqual(self.telo1._max_tarhely, maxtarhely,
                             msg=f"{msg} a _max_tarhely adattag erteket.{diff(self.telo1._max_tarhely, maxtarhely)}")
            self.feladat_pont += 2
        except Exception as e:
            print(e)
        try:
            self.assertDictEqual(self.telo1.alkalmazasok, dict(),
                                 msg=f"{msg} az alkalmazasok adattag erteket.{diff(self.telo1.alkalmazasok, dict())}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        print(f"Feladatra kapott pontszám: {self.feladat_pont}/4")
        pontszam += self.feladat_pont
        print(f"Össz pontszám: {pontszam}/30")
        print("-" * 80)

    def test_getter(self):
        global pontszam
        msg = "A getter nem adta vissza jol a _max_tarhely adattag erteket"
        print("max_tarhely getter tesztelese:")
        print("-" * 30)
        try:
            self.assertEqual(self.telo1.max_tarhely, 4000,
                             msg=f"{msg}.{diff(self.telo1.sorozatszam, 4000)}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        print(f"Feladatra kapott pontszám: {self.feladat_pont}/1")
        pontszam += self.feladat_pont
        print(f"Össz pontszám: {pontszam}/30")
        print("-" * 80)

    def test_setter(self):
        global pontszam
        msg = "A setter nem allitotta be jol a _max_tarhely adattag erteket"
        print("max_tarhely setter tesztelese:")
        print("-" * 30)
        try:
            self.telo1.max_tarhely = '468'
            self.assertEqual(self.telo1.max_tarhely, -1,
                             msg=f"{msg}.{diff(self.telo1.sorozatszam, -1)}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo1.max_tarhely = -50
            self.assertEqual(self.telo1.max_tarhely, -1,
                             msg=f"{msg}.{diff(self.telo1.sorozatszam, -1)}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo1.max_tarhely = 468
            self.assertEqual(self.telo1.max_tarhely, 468,
                             msg=f"{msg}.{diff(self.telo1.sorozatszam, 468)}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo1.max_tarhely = 518.97
            self.assertEqual(self.telo1.max_tarhely, 518.97,
                             msg=f"{msg}.{diff(self.telo1.sorozatszam, 518.97)}")
            self.feladat_pont += 2
        except Exception as e:
            print(e)

        print(f"Feladatra kapott pontszám: {self.feladat_pont}/5")
        pontszam += self.feladat_pont
        print(f"Össz pontszám: {pontszam}/30")
        print("-" * 80)

    def test_str(self):
        global pontszam
        elvart1 = "MEDIMADIPHONE telefonban 3357 MB szabad hely van"
        elvart2 = "EPOLFON telefonban 2985 MB szabad hely van"
        elvart3 = "EPOLFON telefonban 2774 MB szabad hely van"
        msg = "Az __str__ nem jol adta vissza a szoveget"
        print("__str__ tesztelese:")
        print("-" * 30)
        try:
            self.telo1.alkalmazasok = self.apps1
            self.assertEqual(str(self.telo1), elvart1,
                             msg=f"{msg}.{diff(self.telo1, elvart1)}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo2.alkalmazasok = self.apps2
            self.assertEqual(str(self.telo2), elvart2,
                             msg=f"{msg}.{diff(self.telo2, elvart2)}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo2.alkalmazasok = self.apps3
            self.assertEqual(str(self.telo2), elvart3,
                             msg=f"{msg}.{diff(self.telo2, elvart3)}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        print(f"Feladatra kapott pontszám: {self.feladat_pont}/3")
        pontszam += self.feladat_pont
        print(f"Össz pontszám: {pontszam}/30")
        print("-" * 80)

    def test_felteteles_elkodolas(self):
        global pontszam
        msg = "A felteteles_kodolas nem jo dictionary-vel tert vissza"
        print("felteteles_elkodolas tesztelese:")
        print("-" * 30)
        try:
            self.assertDictEqual(self.telo1.felteteles_elkodolas(), {},
                                 msg=f"{msg}.{diff(self.telo1.felteteles_elkodolas(), {})}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo1.alkalmazasok = self.apps1
            self.assertDictEqual(self.telo1.felteteles_elkodolas(), {'regnessem': 369},
                                 msg=f"{msg}.{diff(self.telo1.felteteles_elkodolas(), {'regnessem': 369})}")
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo1.alkalmazasok = self.apps2
            self.assertDictEqual(self.telo1.felteteles_elkodolas(), {'koobecaf': 169, 'regnessem': 188},
                                 msg=f"{msg}.{diff(self.telo1.felteteles_elkodolas(), {'koobecaf': 169, 'regnessem': 188})}")
            self.feladat_pont += 2
        except Exception as e:
            print(e)

        try:
            self.telo1.alkalmazasok = self.apps3
            self.assertDictEqual(self.telo1.felteteles_elkodolas(), {'margatsni': 211, 'regnessem': 188},
                                 msg=f"{msg}.{diff(self.telo1.felteteles_elkodolas(), {'koobecaf': 169, 'regnessem': 188})}")
            self.feladat_pont += 2
        except Exception as e:
            print(e)

        print(f"Feladatra kapott pontszám: {self.feladat_pont}/6")
        pontszam += self.feladat_pont
        print(f"Össz pontszám: {pontszam}/30")
        print("-" * 80)

    def test_isub(self):
        global pontszam
        msg = "A torlessel hiba volt, ha ez volt a bejovo parameter:"
        print("__isub__ tesztelese:")
        print("-" * 30)
        try:
            self.telo1.alkalmazasok = self.apps2
            self.telo1 -= "asd"
            print(f"{msg} 'asd', exceptiont kellett volna dobjon")
        except ValueError:
            self.feladat_pont += 2
        except Exception:
            print(f"{msg} 'asd', ValueError tipusu kivetelt kellett volna dobjon")

        try:
            self.telo1.alkalmazasok = self.apps2
            self.telo1 -= "messenger"
            self.assertDictEqual(self.telo1.alkalmazasok, {'facebook': 169, 'discord': 138},
                                 msg=f"{msg} 'messenger'.{diff(self.telo1.alkalmazasok, {'facebook': 169, 'discord': 138})}")
            self.feladat_pont += 2
        except Exception as e:
            print(e)

        try:
            self.telo1.alkalmazasok = self.apps3
            self.telo1 -= "iNsTagRaM"
            self.assertDictEqual(self.telo1.alkalmazasok, {'facebook': 169, 'messenger': 188, 'discord': 138},
                                 msg=f"{msg} 'iNsTagRaM'.{diff(self.telo1.alkalmazasok, {'facebook': 169, 'messenger': 188, 'discord': 138})}")
            self.feladat_pont += 2
        except Exception as e:
            print(e)

        print(f"Feladatra kapott pontszám: {self.feladat_pont}/6")
        pontszam += self.feladat_pont
        print(f"Össz pontszám: {pontszam}/30")
        print("-" * 80)

    def test_eq(self):
        global pontszam
        msg1 = "A ket objektum kulonbozo volt, megis True-val tert vissza"
        msg2 = "A ket objektum egyforma volt, megis False-szal tert vissza"
        msg3 = "Nem masik Telefonnal lett osszehasolitva, megis True-val tert vissza"
        print("__eq__ tesztelese:")
        print("-" * 30)

        try:
            self.assertFalse(self.telo1 == 'asd', msg=msg3)
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo1.alkalmazasok = self.apps3
            self.telo2.sorozatszam = 'MEDIMADIPHONE'
            self.telo2.max_tarhely = 368
            self.telo2.alkalmazasok = self.apps3
            self.assertFalse(self.telo1 == self.telo2, msg=msg1)
            self.feladat_pont += 1
        except Exception as e:
            print(e)

        try:
            self.telo1.alkalmazasok = self.apps3
            self.telo2.sorozatszam = 'MEDIMADIPHONE'
            self.telo2.max_tarhely = 4000
            self.telo2.alkalmazasok = self.apps3
            self.assertTrue(self.telo1 == self.telo2, msg=msg2)
            self.feladat_pont += 2
        except Exception as e:
            print(e)

        print(f"Feladatra kapott pontszám: {self.feladat_pont}/4")
        pontszam += self.feladat_pont
        print(f"Össz pontszám: {pontszam}/30")
        print("-" * 80)


if __name__ == '__main__':
    unittest.main()
