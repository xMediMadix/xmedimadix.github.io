class Telefon:
    def __init__(self, sorozatszam: str, max_tarhely: int = 4000):
        self.sorozatszam = sorozatszam
        self._max_tarhely = max_tarhely
        self.alkalmazasok = dict()

    @property
    def max_tarhely(self):
        return self._max_tarhely

    @max_tarhely.setter
    def max_tarhely(self, uj):
        self._max_tarhely = uj if isinstance(uj, (int, float)) and uj > 0 else -1

    def __str__(self):
        return f"{self.sorozatszam} telefonban {self._max_tarhely - sum([self.alkalmazasok[app] for app in self.alkalmazasok])} MB szabad hely van"

    def felteteles_elkodolas(self) -> dict:
        if len(self.alkalmazasok) == 0:
            return dict()

        atlag = sum([self.alkalmazasok[app] for app in self.alkalmazasok]) / len(self.alkalmazasok)
        uj = dict()
        for k, v in self.alkalmazasok.items():
            if v > atlag:
                uj[k[::-1]] = v

        return uj

    def __isub__(self, other: str):
        if other.lower() not in self.alkalmazasok:
            raise ValueError
        # ha nem dobott kivetelt akkor biztosan benne van:
        del self.alkalmazasok[other.lower()]
        return self

    def __eq__(self, other):
        return isinstance(other, Telefon) and self.__dict__ == other.__dict__


if __name__ == '__main__':
    telefon1 = Telefon("XI789456123")
    telefon1.max_tarhely = 1000
    telefon1.alkalmazasok = {"facebook": 135, "messenger": 369, "discord": 139}

    print(telefon1)
    print(telefon1.felteteles_elkodolas())
    telefon1 -= "faceBOOK"

    telefon2 = Telefon("XI789456123", 1000)
    telefon2.alkalmazasok = {"messenger": 369, "discord": 139}
    print(telefon1 == telefon2)
