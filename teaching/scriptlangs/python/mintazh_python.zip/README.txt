A feladat megoldását feladat.py néven mentsd el, mert ezt fogja a kiértékelő átnézni.
- A kiértékelőt futtathatod:
	- terminálban: python kiertekelo.py vagy python3 kiertekelo.py
	- fejlesztői környezetben (pl. pycharm) main melletti kis zöld ikonra kattintva
	
Mindegyik fájl egy mappán belül kell legyen!
