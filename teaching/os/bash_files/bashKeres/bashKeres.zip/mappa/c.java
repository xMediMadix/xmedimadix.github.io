public class C{
	public String Bash;
}
