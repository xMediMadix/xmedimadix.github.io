#!/bin/bash

function keresrekurziv (){
	if [[ ! -e $1 ]] ; then
	  	#megoldas
	fi
	
	if [[ ! -d $1 ]] ; then
		#megoldas
	fi
	for i in `ls $1` ; do
		#megoldas
	done
}

keresrekurziv $1
