public class Discord{
	public static void main(String[] args) {
		System.out.println("Eljenek az emotikonok!!44!negy");
	}
}
