#!/bin/bash

function keres (){
	#megoldas
}


keres $1
